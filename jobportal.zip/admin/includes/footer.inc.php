<p>Copyright (c) 2023 jobscope.com. All rights reserved. <br />
			Design by Pawan PINJARI & GAURAV MOKONE</p>