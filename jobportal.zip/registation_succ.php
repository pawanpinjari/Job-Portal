<html>
<head>

<?php
include("includes/head.inc.php");
?>
</head>
<body style="background-color: #8bc34a;">
<marquee behavior="" direction="" class="marquee">JOB PORTAL</marquee>   
    <div id='card'>
      <!-- <div id='upper-side'>
        <h3 id='status'>
          registratiton Success
        </h3>
      </div> -->
      <div id='lower-side'>
        <img src="./images/success.png" alt="">
        <!-- <p id='message'>
          Congratulations, your account has been successfully created.
        </p> -->
        <h1 id='status'>
          registratiton Success
        </h1>
        <a href="index.php" id="contBtn">login here</a>
      </div>
    </div>

</body>
</html>
